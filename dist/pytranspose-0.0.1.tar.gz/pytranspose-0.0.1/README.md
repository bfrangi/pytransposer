pytranspose 
==========

[![Build Status](https://github.com/bfrangi/transposer/workflows/CI/badge.svg)](https://github.com/bfrangi/transposer/actions?query=workflow%3ACI)

Transposing chords from one key to another and changing between DO-RE-MI and A-B-C notations.