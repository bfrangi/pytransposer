def test():
    print('This is working')